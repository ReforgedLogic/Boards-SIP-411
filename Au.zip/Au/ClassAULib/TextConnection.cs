﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassAULib.TextHelper;

namespace ClassAULib
{
    public class TextConnection : IData
    {
        private const string NurseFile = "nurses.csv";
        private const string PatientFile = "patients.csv";
        private const string UnitFile = "units.csv";
        public Nurse CreateNurse(Nurse model)
        {
            // load  the text file
            // convert txt file to model
            List<Nurse> nurses = NurseFile.FullFilePath().LoadFile().ConvertToNurseModel();

            // find max id
            int currentId = 1;
            if (nurses.Count >= 1)
            {
                currentId = nurses.OrderByDescending(x => x.Id).First().Id + 1;
            }
            model.Id = currentId;

            // add record with new id
            nurses.Add(model);

            // convert nurses to List<string>
            // save the List<string> to the file
            nurses.SaveToNurseFile(NurseFile);

            // return the model with ID
            return model;

        }

        public Patient CreatePatient(Patient model)
        {
            // laod the text file
            // convert txt file to model
            List<Patient> patients = PatientFile.FullFilePath().LoadFile().ConvertToPatientModel();

            // find max id
            int currentId = 1;
            if (patients.Count >= 1)
            {
                currentId = patients.OrderByDescending(x => x.Id).First().Id + 1;
            }
            model.Id = currentId;

            // add record with new id
            patients.Add(model);

            // convert nurses to List<string>
            // save the List<string> to the file
            patients.SaveToPatientFile(PatientFile);

            // retrun the model with ID
            return model;
        }

        public Unit CreateUnit(Unit model)
        {
            // laod the text file
            // convert txt file to model
            List<Unit> units = UnitFile.FullFilePath().LoadFile().ConvertToUnitModel(NurseFile, PatientFile);

            // find max id
            int currentId = 1;
            if (units.Count >= 1)
            {
                currentId = units.OrderByDescending(x => x.Id).First().Id + 1;
            }
            model.Id = currentId;

            // add record with new id
            units.Add(model);

            // convert nurses to List<string>
            // save the List<string> to the file
            units.SaveToUnitFile(UnitFile);

            // retrun the model with ID
            return model;
        }

        public List<Nurse> GetAllNurses()
        {
            return NurseFile.FullFilePath().LoadFile().ConvertToNurseModel();
        }

        public List<Patient> GetAllPatients()
        {
            return PatientFile.FullFilePath().LoadFile().ConvertToPatientModel();
        }
    }
}
