﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassAULib
{
    public class Patient
    {
        public Patient() { }

        public Patient(string fn, string ln, string cc, string al)
        {
            FirstName = fn;
            LastName = ln;
            ChiefComplaint = cc;

            int acutiyLevelValue = 0;
            int.TryParse(al, out acutiyLevelValue);
            AcuityLevel = acutiyLevelValue;
        }
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ChiefComplaint { get; set; }
        public int AcuityLevel { get; set; }
        public string FullName
        {
            get 
            { 
                return $"{ FirstName } { LastName }"; 
            }
        }
        public string PatientDisplayInfo
        {
            get
            {
                return $"{FirstName} {LastName} Acuity: [{ AcuityLevel }]";
            }
            
        }


    }
}
