﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassAULib
{
    public static class GlobalConfig
    {
        public static IData Connection { get; private set; }

        public static void InitializeConnections(bool textFile)
        {
            if (textFile)
            {
                TextConnection text = new TextConnection();
                Connection = text;
            }
        }
    }
}
