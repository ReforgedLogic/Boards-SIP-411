﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassAULib.TextHelper
{
    public static class TextProcessor
    {
        public static string FullFilePath(this string fileName)
        {
            return $"{ ConfigurationManager.AppSettings["filePath"] }\\{ fileName }";
        }

        public static List<string> LoadFile(this string file)
        {
            if (!File.Exists(file))
            {
                return new List<string>();
            }

            return File.ReadAllLines(file).ToList();
        }

        public static List<Nurse> ConvertToNurseModel(this List<string> lines)
        {
            List<Nurse> output = new List<Nurse>();

            foreach (string line in lines)
            {
                string[] cols = line.Split(',');
                Nurse n = new Nurse();
                n.Id = int.Parse(cols[0]);
                n.FirstName = cols[1];
                n.LastName = cols[2];
                n.Initials = cols[3];
                n.AcuityLevel = int.Parse(cols[4]);
                output.Add(n);
            }

            return output;
        }
        public static List<Patient> ConvertToPatientModel(this List<string> lines)
        {
            List<Patient> output = new List<Patient>();

            foreach (string line in lines)
            {
                string[] cols = line.Split(',');
                Patient p = new Patient();
                p.Id = int.Parse(cols[0]);
                p.FirstName = cols[1];
                p.LastName = cols[2];
                p.ChiefComplaint = cols[3];
                p.AcuityLevel = int.Parse(cols[4]);
                output.Add(p);
            }

            return output;
        }
        public static List<Unit> ConvertToUnitModel(this List<string> lines, string nurseFileName, string patientFileName)
        {
            List<Unit> output = new List<Unit>();
            List<Nurse> nurses = nurseFileName.FullFilePath().LoadFile().ConvertToNurseModel();
            List<Patient> patients = patientFileName.FullFilePath().LoadFile().ConvertToPatientModel();
            Console.WriteLine(nurses);

            foreach (string line in lines)
            {
                string[] cols = line.Split(',');
                Unit u = new Unit();
                u.Id = int.Parse(cols[0]);
                u.UnitName = cols[1];
                u.UnitAcronym = cols[2];

                string[] idNurse = cols[3].Split('|');
                foreach (string id in idNurse)
                {
                    u.Nurses.Add(nurses.Where(x => x.Id == int.Parse(id)).First());
                }

                string[] idPatient = cols[4].Split('|');
                foreach (string id in idPatient)
                {
                   u.Patients.Add(patients.Where(x => x.Id == int.Parse(id)).First());
                }
                output.Add(u);
            }

            return output;
        }

        public static void SaveToNurseFile(this List<Nurse> model, string fileName)
        {
            List<string> lines = new List<string>();

            foreach (Nurse n in model)
            {
                lines.Add($"{ n.Id },{ n.FirstName },{ n.LastName },{ n.Initials },{ n.AcuityLevel }");
            }

            File.WriteAllLines(fileName.FullFilePath(), lines);
        }
        public static void SaveToPatientFile(this List<Patient> model, string fileName)
        {
            List<string> lines = new List<string>();

            foreach (Patient p in model)
            {
                lines.Add($"{ p.Id },{ p.FirstName },{ p.LastName },{ p.ChiefComplaint },{ p.AcuityLevel }");
            }

            File.WriteAllLines(fileName.FullFilePath(), lines);
        }
        public static void SaveToUnitFile(this List<Unit> model, string fileName)
        {
            List<string> lines = new List<string>();

            foreach (Unit u in model)
            {
                lines.Add($"{ u.Id },{ u.UnitName },{ u.UnitAcronym },{ ConvertNurseListToString(u.Nurses) },{ ConvertPatientListToString(u.Patients)}");
            }

            File.WriteAllLines(fileName.FullFilePath(), lines);
        }

        private static string ConvertNurseListToString(List<Nurse> nurse)
        {
            string output = "";

            if (nurse.Count == 0)
            {
                return "";
            }

            foreach (Nurse n in nurse)
            {
                output += $"{ n.Id }|";
            }

            output = output.Substring(0, output.Length - 1);

            return output;
        }

        private static string ConvertPatientListToString(List<Patient> patient)
        {
            string output = "";

            if (patient.Count == 0)
            {
                return "";
            }

            foreach (Patient p in patient)
            {
                output += $"{ p.Id }|";
            }

            output = output.Substring(0, output.Length - 1);

            return output;
        }
    }
}
