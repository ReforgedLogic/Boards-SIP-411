﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassAULib
{
    public class Unit
    {
        public int Id { get; set; }
        public string UnitName { get; set; }
        public string UnitAcronym { get; set; }

        public List<Nurse> Nurses { get; set; } = new List<Nurse>();
        public List<Patient> Patients { get; set; } = new List<Patient>();
    }
}
