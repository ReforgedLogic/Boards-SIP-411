﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassAULib
{
    public interface IData
    {
        Nurse CreateNurse(Nurse model);
        Patient CreatePatient(Patient model);
        Unit CreateUnit(Unit model);

        List<Nurse> GetAllNurses();
        List<Patient> GetAllPatients();
    }
}
