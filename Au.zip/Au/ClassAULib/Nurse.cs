﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassAULib
{
    public class Nurse
    {
        public Nurse() { }
        public Nurse(string fn, string ln, string i, string al)
        {
            FirstName = fn;
            LastName = ln;
            Initials = i;

            int acutiyLevelValue = 0;
            int.TryParse(al, out acutiyLevelValue);
            AcuityLevel = acutiyLevelValue;
        }
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Initials { get; set; }
        public int AcuityLevel { get; set; }
        public int AcuityPotential { get; set; } = -1;
        public bool isAvailable { get; set; } = true;
        public string FullName 
        {
            get 
            {
                return $"{ FirstName } { LastName }";
            }
        }
    }
}
