﻿using ClassAULib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Au
{
    public partial class AwareUnit : Form
    {
        private List<Nurse> availableNurses = new List<Nurse>();
        private List<Patient> availablePatients = new List<Patient>();
        private List<Unit> availableUnitsOptions = new List<Unit>();
        private List<Nurse> selectedNurses = new List<Nurse>();
        private List<Patient> selectedPatients = new List<Patient>();
        private List<Patient> unassignedPatient = new List<Patient>();
        private Dictionary<Nurse, List<Patient>> Assignments = new Dictionary<Nurse, List<Patient>>();
        /// <summary>
        /// 
        /// </summary>
        public AwareUnit()
        {
            InitializeComponent();
            // SampleData(); // SAMPLE DATA !!!... method below for testing
            LoadListData();
            WireUpNurseList();
            UnitAcronymDisplay.Text = "Emergency Department";
        }

        private void CreateNurse_Click(object sender, EventArgs e)
        {
            if (ValidateNurse())
            {
                Nurse model = new Nurse(
                    NurseFirstname.Text,
                    NurseLastname.Text,
                    NurseInitials.Text,
                    NurseAcutiyLevel.Text);
                model = GlobalConfig.Connection.CreateNurse(model);
                selectedNurses.Add(model);
                WireUpNurseList();
                ResetNurseFields();
            }
            else
            {
                MessageBox.Show("Incorrect Nurse Infromation. Please check and try again.");
            }
        }
        private void CreatePatient_Click(object sender, EventArgs e)
        {
            if (ValidatePatient())
            {
                Patient model = new Patient(
                    PatientFirstname.Text,
                    PatientLastname.Text,
                    PatientChiefComplaint.Text,
                    PatientAcuityLevel.Text);
                model = GlobalConfig.Connection.CreatePatient(model);
                selectedPatients.Add(model);
                WireUpNurseList();
                ResetPatientFields();
            }
            else
            {
                MessageBox.Show("Incorrect Patient Infromation. Please check and try again.");
            }
        }
        private void CreateUnit_Click(object sender, EventArgs e)
        {
            string unitAcronym = SetUnitAcronym();

            if (ValidateUnitAcronym(unitAcronym) && ValidateUnit())
            {
                Unit u = new Unit
                {
                    UnitName = SelectUnit.Text,
                    UnitAcronym = unitAcronym,
                    Nurses = selectedNurses,
                    Patients = selectedPatients
                };

                u = GlobalConfig.Connection.CreateUnit(u);

                // Compar acuity nurse a to pt a
                // if a matches assign pt to nurse if nurse 
                AssignPatientsToNurse();

                DisplayData();
            }
        }

        private void AddNurse_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Nurse n = (Nurse)SelectNurseDropDown.SelectedItem;
            if (n != null)
            {
                availableNurses.Remove(n);
                selectedNurses.Add(n);
                WireUpNurseList();
            }
        }
        private void RemoveNurse_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Nurse n = (Nurse)ListNurses.SelectedItem;
            if (n != null)
            {
                selectedNurses.Remove(n);
                availableNurses.Add(n);
                WireUpNurseList();
            }
        }

        private void AddPatient_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Patient p = (Patient)SelectedPatientDropDown.SelectedItem;
            if (p != null)
            {
                availablePatients.Remove(p);
                selectedPatients.Add(p);
                WireUpNurseList();
            }
        }
        private void RemovePatient_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Patient p = (Patient)ListPatients.SelectedItem;
            if (p != null)
            {
                selectedPatients.Remove(p);
                availablePatients.Add(p);
                WireUpNurseList();
            }
        }
        private void SelectUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            UnitAcronymDisplay.Text = SelectUnit.Text;
        }

        public bool ValidateNurse()
        {
            bool output = true;
            int acutiyNumber = 0;
            bool validAcuityNumber = int.TryParse(NurseAcutiyLevel.Text, out acutiyNumber);

            if (!validAcuityNumber)
            {
                output = false;
            }

            if (acutiyNumber < 1)
            {
                output = false;
            }

            if (acutiyNumber > 5)
            {
                output = false;
            }

            if (NurseInitials.Text.Length == 0)
            {
                output = false;
            }

            if (NurseLastname.Text.Length == 0)
            {
                output = false;
            }

            if (NurseFirstname.Text.Length == 0)
            {
                output = false;
            }

            return output;
        }
        public bool ValidatePatient()
        {
            bool output = true;
            int acutiyNumber = 0;
            bool validAcuityNumber = int.TryParse(PatientAcuityLevel.Text, out acutiyNumber);

            if (!validAcuityNumber)
            {
                output = false;
            }

            if (acutiyNumber < 1)
            {
                output = false;
            }

            if (acutiyNumber > 5)
            {
                output = false;
            }

            if (PatientChiefComplaint.Text.Length == 0)
            {
                output = false;
            }

            if (PatientLastname.Text.Length == 0)
            {
                output = false;
            }

            if (PatientFirstname.Text.Length == 0)
            {
                output = false;
            }

            return output;
        }
        public bool ValidateUnit()
        {
            bool output = false;

            if (SelectUnit.Text.Length == 0)
            {
                output = false;
            }

            if (SelectUnit.Text == "Emergency Department")
            {
                output = true;
            }

            if (SelectUnit.Text == "Post Anesthesia Care Unit")
            {
                output = true;
            }

            if (SelectUnit.Text == "Neonatal Intensive Care Unit")
            {
                output = true;
            }

            if (SelectUnit.Text == "Pediactric Intensive Care Unit")
            {
                output = true;
            }

            if (SelectUnit.Text == "Pediactric Medical Surgical Unit")
            {
                output = true;
            }

            return output;
        }
        public bool ValidateUnitAcronym(string acronym)
        {
            bool output = false;

            if (acronym == "ED")
            {
                output = true;
            }

            if (acronym == "PACU")
            {
                output = true;
            }

            if (acronym == "NICU")
            {
                output = true;
            }

            if (acronym == "PICU")
            {
                output = true;
            }

            if (acronym == "Peds Med Surg")
            {
                output = true;
            }

            return output;
        }


        public void ResetNurseFields()
        {
            NurseFirstname.Text = "";
            NurseLastname.Text = "";
            NurseInitials.Text = "";
            NurseAcutiyLevel.Text = "";
        }
        public void ResetPatientFields()
        {
            PatientFirstname.Text = "";
            PatientLastname.Text = "";
            PatientChiefComplaint.Text = "";
            PatientAcuityLevel.Text = "";
        }


        private void WireUpNurseList()
        {
            SelectNurseDropDown.DataSource = null;
            SelectNurseDropDown.DataSource = availableNurses;
            SelectNurseDropDown.DisplayMember = "FullName";

            SelectedPatientDropDown.DataSource = null;
            SelectedPatientDropDown.DataSource = availablePatients;
            SelectedPatientDropDown.DisplayMember = "FullName";

            SelectUnit.DataSource = null;
            SelectUnit.DataSource = availablePatients;
            SelectUnit.DisplayMember = "FullName";

            ListNurses.DataSource = null;
            ListNurses.DataSource = selectedNurses;
            ListNurses.DisplayMember = "FullName";

            ListPatients.DataSource = null;
            ListPatients.DataSource = selectedPatients;
            ListPatients.DisplayMember = "FullName";

            SelectUnit.DataSource = null;
            SelectUnit.DataSource = availableUnitsOptions;
            SelectUnit.DisplayMember = "UnitName";



        }
        private void SampleData()
        {
            availableNurses.Add(new Nurse { FirstName = "Jay", LastName = "Carney" });
            availableNurses.Add(new Nurse { FirstName = "Kirstin", LastName = "Miles" });

            selectedNurses.Add(new Nurse { FirstName = "Jistin", LastName = "Miles" });
            selectedNurses.Add(new Nurse { FirstName = "Doug", LastName = "Swanson" });
        }
        private void UnitOtpionData()
        {
            availableUnitsOptions.Add(new Unit { UnitName = "Emergency Department" });
            availableUnitsOptions.Add(new Unit { UnitName = "Post Anesthesia Care Unit" });
            availableUnitsOptions.Add(new Unit { UnitName = "Neonatal Intensive Care Unit" });
            availableUnitsOptions.Add(new Unit { UnitName = "Pediactric Intensive Care Unit" });
            availableUnitsOptions.Add(new Unit { UnitName = "Pediactric Medical Surgical Unit" });
        }
        private void LoadListData()
        {
            UnitOtpionData();
            availableNurses = GlobalConfig.Connection.GetAllNurses();
            availablePatients = GlobalConfig.Connection.GetAllPatients();
        }
        public string SetUnitAcronym()
        {
            string output = "";

            if (SelectUnit.Text.Length == 0)
            {
                return output;
            }

            if (SelectUnit.Text == "Emergency Department")
            {
                output = "ED";
            }

            if (SelectUnit.Text == "Post Anesthesia Care Unit")
            {
                output = "PACU";
            }

            if (SelectUnit.Text == "Neonatal Intensive Care Unit")
            {
                output = "NICU";
            }

            if (SelectUnit.Text == "Pediactric Intensive Care Unit")
            {
                output = "PICU";
            }

            if (SelectUnit.Text == "Pediactric Medical Surgical Unit")
            {
                output = "Peds Med Surg";
            }
            return output;
        }
        public void AssignPatientsToNurse()
        {
            if (selectedPatients.Count == 0 || selectedNurses.Count == 0)
            {
                return;
            }

            foreach (Nurse selectedNurse in selectedNurses)
            {
                Assignments.Add(selectedNurse, new List<Patient>());
            }

            for (int acuityLevel = 1; acuityLevel <= 5; acuityLevel++)
            {
                List<Patient> patients = selectedPatients.FindAll(p => p.AcuityLevel == acuityLevel);
                if (selectedPatients.Count != 0)
                {
                    foreach (Patient currentPatient in patients)
                    {
                        List<Nurse> ableNurses = selectedNurses.FindAll(n => n.AcuityLevel <= acuityLevel && n.isAvailable);

                        if (ableNurses.Count == 0)
                        {
                            unassignedPatient.Add(currentPatient);
                        }
                        else
                        {
                            Nurse currentNurse = ableNurses.First();
                            if (currentNurse.AcuityPotential == -1)
                            {
                                currentNurse.AcuityPotential = acuityLevel;
                            }

                            Assignments[currentNurse].Add(currentPatient);

                            if (Assignments[currentNurse].Count == currentNurse.AcuityPotential)
                            {
                                currentNurse.isAvailable = false;
                            }
                        }
                    }
                }
            }
        }
        private void DisplayData()
        {
            StringBuilder output = new StringBuilder();

            foreach (Nurse nurse in Assignments.Keys)
            {
                output.Append($"{ nurse.FullName } [{ nurse.AcuityLevel }]  Acuity Ability\n");
                foreach (Patient patient in Assignments[nurse])
                {
                    output.Append($"\t{ patient.FullName } [{ patient.ChiefComplaint } | { patient.AcuityLevel}] - Medical Acuity\n");
                }
                output.Append($"\n");
            }

            AssiegnmentDisplay.Text = output.ToString();

            RejectsDisplay();
        }
        private void RejectsDisplay()
        {
            UnassignedPatients.DataSource = null;
            UnassignedPatients.DataSource = unassignedPatient;
            UnassignedPatients.DisplayMember = "PatientDisplayInfo";
        }
    }
}
