﻿
namespace Au
{
    partial class AwareUnit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AwareUnit));
            this.NurseFirstname = new System.Windows.Forms.TextBox();
            this.LNurseInfo = new System.Windows.Forms.Label();
            this.LRNFristname = new System.Windows.Forms.Label();
            this.LRNLastname = new System.Windows.Forms.Label();
            this.NurseLastname = new System.Windows.Forms.TextBox();
            this.LRNInitials = new System.Windows.Forms.Label();
            this.NurseInitials = new System.Windows.Forms.TextBox();
            this.LRNAcuityLevel = new System.Windows.Forms.Label();
            this.NurseAcutiyLevel = new System.Windows.Forms.TextBox();
            this.LPTAcuityLevel = new System.Windows.Forms.Label();
            this.PatientAcuityLevel = new System.Windows.Forms.TextBox();
            this.LPTCheifComplaint = new System.Windows.Forms.Label();
            this.PatientChiefComplaint = new System.Windows.Forms.TextBox();
            this.LPTLastname = new System.Windows.Forms.Label();
            this.PatientLastname = new System.Windows.Forms.TextBox();
            this.LPTFristname = new System.Windows.Forms.Label();
            this.LPTPatientInfo = new System.Windows.Forms.Label();
            this.PatientFirstname = new System.Windows.Forms.TextBox();
            this.CreateNurse = new System.Windows.Forms.Button();
            this.CreatePatient = new System.Windows.Forms.Button();
            this.ListNurses = new System.Windows.Forms.ListBox();
            this.ListPatients = new System.Windows.Forms.ListBox();
            this.UnassignedPatients = new System.Windows.Forms.ListBox();
            this.SelectUnit = new System.Windows.Forms.ComboBox();
            this.LUnit = new System.Windows.Forms.Label();
            this.CreateUnit = new System.Windows.Forms.Button();
            this.UnitAcronymDisplay = new System.Windows.Forms.Label();
            this.RemoveNurse = new System.Windows.Forms.LinkLabel();
            this.RemovePatient = new System.Windows.Forms.LinkLabel();
            this.AddNurse = new System.Windows.Forms.LinkLabel();
            this.SelectNurseDropDown = new System.Windows.Forms.ComboBox();
            this.SelectedPatientDropDown = new System.Windows.Forms.ComboBox();
            this.AddPatient = new System.Windows.Forms.LinkLabel();
            this.AssiegnmentDisplay = new System.Windows.Forms.RichTextBox();
            this.labelUnPt = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // NurseFirstname
            // 
            this.NurseFirstname.Location = new System.Drawing.Point(12, 59);
            this.NurseFirstname.Name = "NurseFirstname";
            this.NurseFirstname.Size = new System.Drawing.Size(100, 20);
            this.NurseFirstname.TabIndex = 0;
            // 
            // LNurseInfo
            // 
            this.LNurseInfo.AutoSize = true;
            this.LNurseInfo.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LNurseInfo.Location = new System.Drawing.Point(11, 23);
            this.LNurseInfo.Name = "LNurseInfo";
            this.LNurseInfo.Size = new System.Drawing.Size(84, 20);
            this.LNurseInfo.TabIndex = 1;
            this.LNurseInfo.Text = "Nurse Info";
            // 
            // LRNFristname
            // 
            this.LRNFristname.AutoSize = true;
            this.LRNFristname.Location = new System.Drawing.Point(12, 43);
            this.LRNFristname.Name = "LRNFristname";
            this.LRNFristname.Size = new System.Drawing.Size(52, 13);
            this.LRNFristname.TabIndex = 2;
            this.LRNFristname.Text = "Firstname";
            // 
            // LRNLastname
            // 
            this.LRNLastname.AutoSize = true;
            this.LRNLastname.Location = new System.Drawing.Point(12, 82);
            this.LRNLastname.Name = "LRNLastname";
            this.LRNLastname.Size = new System.Drawing.Size(53, 13);
            this.LRNLastname.TabIndex = 4;
            this.LRNLastname.Text = "Lastname";
            // 
            // NurseLastname
            // 
            this.NurseLastname.Location = new System.Drawing.Point(12, 98);
            this.NurseLastname.Name = "NurseLastname";
            this.NurseLastname.Size = new System.Drawing.Size(100, 20);
            this.NurseLastname.TabIndex = 3;
            // 
            // LRNInitials
            // 
            this.LRNInitials.AutoSize = true;
            this.LRNInitials.Location = new System.Drawing.Point(12, 121);
            this.LRNInitials.Name = "LRNInitials";
            this.LRNInitials.Size = new System.Drawing.Size(36, 13);
            this.LRNInitials.TabIndex = 6;
            this.LRNInitials.Text = "Initials";
            // 
            // NurseInitials
            // 
            this.NurseInitials.Location = new System.Drawing.Point(12, 137);
            this.NurseInitials.Name = "NurseInitials";
            this.NurseInitials.Size = new System.Drawing.Size(100, 20);
            this.NurseInitials.TabIndex = 5;
            // 
            // LRNAcuityLevel
            // 
            this.LRNAcuityLevel.AutoSize = true;
            this.LRNAcuityLevel.Location = new System.Drawing.Point(12, 160);
            this.LRNAcuityLevel.Name = "LRNAcuityLevel";
            this.LRNAcuityLevel.Size = new System.Drawing.Size(65, 13);
            this.LRNAcuityLevel.TabIndex = 8;
            this.LRNAcuityLevel.Text = "Acutiy Level";
            // 
            // NurseAcutiyLevel
            // 
            this.NurseAcutiyLevel.Location = new System.Drawing.Point(12, 176);
            this.NurseAcutiyLevel.Name = "NurseAcutiyLevel";
            this.NurseAcutiyLevel.Size = new System.Drawing.Size(100, 20);
            this.NurseAcutiyLevel.TabIndex = 7;
            // 
            // LPTAcuityLevel
            // 
            this.LPTAcuityLevel.AutoSize = true;
            this.LPTAcuityLevel.Location = new System.Drawing.Point(12, 417);
            this.LPTAcuityLevel.Name = "LPTAcuityLevel";
            this.LPTAcuityLevel.Size = new System.Drawing.Size(65, 13);
            this.LPTAcuityLevel.TabIndex = 17;
            this.LPTAcuityLevel.Text = "Acutiy Level";
            // 
            // PatientAcuityLevel
            // 
            this.PatientAcuityLevel.Location = new System.Drawing.Point(12, 433);
            this.PatientAcuityLevel.Name = "PatientAcuityLevel";
            this.PatientAcuityLevel.Size = new System.Drawing.Size(100, 20);
            this.PatientAcuityLevel.TabIndex = 16;
            // 
            // LPTCheifComplaint
            // 
            this.LPTCheifComplaint.AutoSize = true;
            this.LPTCheifComplaint.Location = new System.Drawing.Point(12, 378);
            this.LPTCheifComplaint.Name = "LPTCheifComplaint";
            this.LPTCheifComplaint.Size = new System.Drawing.Size(80, 13);
            this.LPTCheifComplaint.TabIndex = 15;
            this.LPTCheifComplaint.Text = "Cheif Complaint";
            // 
            // PatientChiefComplaint
            // 
            this.PatientChiefComplaint.Location = new System.Drawing.Point(12, 394);
            this.PatientChiefComplaint.Name = "PatientChiefComplaint";
            this.PatientChiefComplaint.Size = new System.Drawing.Size(100, 20);
            this.PatientChiefComplaint.TabIndex = 14;
            // 
            // LPTLastname
            // 
            this.LPTLastname.AutoSize = true;
            this.LPTLastname.Location = new System.Drawing.Point(12, 339);
            this.LPTLastname.Name = "LPTLastname";
            this.LPTLastname.Size = new System.Drawing.Size(53, 13);
            this.LPTLastname.TabIndex = 13;
            this.LPTLastname.Text = "Lastname";
            // 
            // PatientLastname
            // 
            this.PatientLastname.Location = new System.Drawing.Point(12, 355);
            this.PatientLastname.Name = "PatientLastname";
            this.PatientLastname.Size = new System.Drawing.Size(100, 20);
            this.PatientLastname.TabIndex = 12;
            // 
            // LPTFristname
            // 
            this.LPTFristname.AutoSize = true;
            this.LPTFristname.Location = new System.Drawing.Point(12, 300);
            this.LPTFristname.Name = "LPTFristname";
            this.LPTFristname.Size = new System.Drawing.Size(52, 13);
            this.LPTFristname.TabIndex = 11;
            this.LPTFristname.Text = "Firstname";
            // 
            // LPTPatientInfo
            // 
            this.LPTPatientInfo.AutoSize = true;
            this.LPTPatientInfo.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPTPatientInfo.Location = new System.Drawing.Point(8, 280);
            this.LPTPatientInfo.Name = "LPTPatientInfo";
            this.LPTPatientInfo.Size = new System.Drawing.Size(92, 20);
            this.LPTPatientInfo.TabIndex = 10;
            this.LPTPatientInfo.Text = "Patient Info";
            // 
            // PatientFirstname
            // 
            this.PatientFirstname.Location = new System.Drawing.Point(12, 316);
            this.PatientFirstname.Name = "PatientFirstname";
            this.PatientFirstname.Size = new System.Drawing.Size(100, 20);
            this.PatientFirstname.TabIndex = 9;
            // 
            // CreateNurse
            // 
            this.CreateNurse.Location = new System.Drawing.Point(12, 202);
            this.CreateNurse.Name = "CreateNurse";
            this.CreateNurse.Size = new System.Drawing.Size(75, 23);
            this.CreateNurse.TabIndex = 18;
            this.CreateNurse.Text = "Create";
            this.CreateNurse.UseVisualStyleBackColor = true;
            this.CreateNurse.Click += new System.EventHandler(this.CreateNurse_Click);
            // 
            // CreatePatient
            // 
            this.CreatePatient.Location = new System.Drawing.Point(12, 459);
            this.CreatePatient.Name = "CreatePatient";
            this.CreatePatient.Size = new System.Drawing.Size(75, 23);
            this.CreatePatient.TabIndex = 19;
            this.CreatePatient.Text = "Create";
            this.CreatePatient.UseVisualStyleBackColor = true;
            this.CreatePatient.Click += new System.EventHandler(this.CreatePatient_Click);
            // 
            // ListNurses
            // 
            this.ListNurses.FormattingEnabled = true;
            this.ListNurses.Location = new System.Drawing.Point(118, 23);
            this.ListNurses.Name = "ListNurses";
            this.ListNurses.Size = new System.Drawing.Size(120, 199);
            this.ListNurses.TabIndex = 20;
            // 
            // ListPatients
            // 
            this.ListPatients.FormattingEnabled = true;
            this.ListPatients.Location = new System.Drawing.Point(118, 280);
            this.ListPatients.Name = "ListPatients";
            this.ListPatients.Size = new System.Drawing.Size(120, 199);
            this.ListPatients.TabIndex = 21;
            // 
            // UnassignedPatients
            // 
            this.UnassignedPatients.FormattingEnabled = true;
            this.UnassignedPatients.Location = new System.Drawing.Point(726, 121);
            this.UnassignedPatients.Name = "UnassignedPatients";
            this.UnassignedPatients.Size = new System.Drawing.Size(177, 329);
            this.UnassignedPatients.TabIndex = 22;
            // 
            // SelectUnit
            // 
            this.SelectUnit.FormattingEnabled = true;
            this.SelectUnit.Location = new System.Drawing.Point(448, 49);
            this.SelectUnit.Name = "SelectUnit";
            this.SelectUnit.Size = new System.Drawing.Size(190, 21);
            this.SelectUnit.TabIndex = 23;
            this.SelectUnit.Text = "Select Unit";
            this.SelectUnit.SelectedIndexChanged += new System.EventHandler(this.SelectUnit_SelectedIndexChanged);
            // 
            // LUnit
            // 
            this.LUnit.AutoSize = true;
            this.LUnit.Font = new System.Drawing.Font("Microsoft YaHei", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LUnit.Location = new System.Drawing.Point(359, 37);
            this.LUnit.Name = "LUnit";
            this.LUnit.Size = new System.Drawing.Size(83, 41);
            this.LUnit.TabIndex = 24;
            this.LUnit.Text = "Unit";
            // 
            // CreateUnit
            // 
            this.CreateUnit.Location = new System.Drawing.Point(256, 43);
            this.CreateUnit.Name = "CreateUnit";
            this.CreateUnit.Size = new System.Drawing.Size(97, 30);
            this.CreateUnit.TabIndex = 25;
            this.CreateUnit.Text = "Create Unit";
            this.CreateUnit.UseVisualStyleBackColor = true;
            this.CreateUnit.Click += new System.EventHandler(this.CreateUnit_Click);
            // 
            // UnitAcronymDisplay
            // 
            this.UnitAcronymDisplay.AutoSize = true;
            this.UnitAcronymDisplay.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UnitAcronymDisplay.Location = new System.Drawing.Point(644, 50);
            this.UnitAcronymDisplay.Name = "UnitAcronymDisplay";
            this.UnitAcronymDisplay.Size = new System.Drawing.Size(86, 20);
            this.UnitAcronymDisplay.TabIndex = 26;
            this.UnitAcronymDisplay.Text = "Unit Name";
            // 
            // RemoveNurse
            // 
            this.RemoveNurse.AutoSize = true;
            this.RemoveNurse.Location = new System.Drawing.Point(147, 225);
            this.RemoveNurse.Name = "RemoveNurse";
            this.RemoveNurse.Size = new System.Drawing.Size(47, 13);
            this.RemoveNurse.TabIndex = 27;
            this.RemoveNurse.TabStop = true;
            this.RemoveNurse.Text = "Remove";
            this.RemoveNurse.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.RemoveNurse_LinkClicked);
            // 
            // RemovePatient
            // 
            this.RemovePatient.AutoSize = true;
            this.RemovePatient.Location = new System.Drawing.Point(147, 482);
            this.RemovePatient.Name = "RemovePatient";
            this.RemovePatient.Size = new System.Drawing.Size(47, 13);
            this.RemovePatient.TabIndex = 28;
            this.RemovePatient.TabStop = true;
            this.RemovePatient.Text = "Remove";
            this.RemovePatient.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.RemovePatient_LinkClicked);
            // 
            // AddNurse
            // 
            this.AddNurse.AutoSize = true;
            this.AddNurse.Location = new System.Drawing.Point(115, 225);
            this.AddNurse.Name = "AddNurse";
            this.AddNurse.Size = new System.Drawing.Size(26, 13);
            this.AddNurse.TabIndex = 29;
            this.AddNurse.TabStop = true;
            this.AddNurse.Text = "Add";
            this.AddNurse.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.AddNurse_LinkClicked);
            // 
            // SelectNurseDropDown
            // 
            this.SelectNurseDropDown.FormattingEnabled = true;
            this.SelectNurseDropDown.Location = new System.Drawing.Point(118, 242);
            this.SelectNurseDropDown.Name = "SelectNurseDropDown";
            this.SelectNurseDropDown.Size = new System.Drawing.Size(121, 21);
            this.SelectNurseDropDown.TabIndex = 30;
            this.SelectNurseDropDown.Text = "Select Nurse";
            // 
            // SelectedPatientDropDown
            // 
            this.SelectedPatientDropDown.FormattingEnabled = true;
            this.SelectedPatientDropDown.Location = new System.Drawing.Point(118, 498);
            this.SelectedPatientDropDown.Name = "SelectedPatientDropDown";
            this.SelectedPatientDropDown.Size = new System.Drawing.Size(121, 21);
            this.SelectedPatientDropDown.TabIndex = 31;
            this.SelectedPatientDropDown.Text = "Select Patient";
            // 
            // AddPatient
            // 
            this.AddPatient.AutoSize = true;
            this.AddPatient.Location = new System.Drawing.Point(115, 482);
            this.AddPatient.Name = "AddPatient";
            this.AddPatient.Size = new System.Drawing.Size(26, 13);
            this.AddPatient.TabIndex = 32;
            this.AddPatient.TabStop = true;
            this.AddPatient.Text = "Add";
            this.AddPatient.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.AddPatient_LinkClicked);
            // 
            // AssiegnmentDisplay
            // 
            this.AssiegnmentDisplay.Location = new System.Drawing.Point(256, 82);
            this.AssiegnmentDisplay.Name = "AssiegnmentDisplay";
            this.AssiegnmentDisplay.Size = new System.Drawing.Size(455, 430);
            this.AssiegnmentDisplay.TabIndex = 33;
            this.AssiegnmentDisplay.Text = "";
            // 
            // labelUnPt
            // 
            this.labelUnPt.AutoSize = true;
            this.labelUnPt.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUnPt.Location = new System.Drawing.Point(737, 98);
            this.labelUnPt.Name = "labelUnPt";
            this.labelUnPt.Size = new System.Drawing.Size(155, 20);
            this.labelUnPt.TabIndex = 34;
            this.labelUnPt.Text = "Unassigned Patients";
            // 
            // AwareUnit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 524);
            this.Controls.Add(this.labelUnPt);
            this.Controls.Add(this.AssiegnmentDisplay);
            this.Controls.Add(this.AddPatient);
            this.Controls.Add(this.SelectedPatientDropDown);
            this.Controls.Add(this.SelectNurseDropDown);
            this.Controls.Add(this.AddNurse);
            this.Controls.Add(this.RemovePatient);
            this.Controls.Add(this.RemoveNurse);
            this.Controls.Add(this.UnitAcronymDisplay);
            this.Controls.Add(this.CreateUnit);
            this.Controls.Add(this.LUnit);
            this.Controls.Add(this.SelectUnit);
            this.Controls.Add(this.UnassignedPatients);
            this.Controls.Add(this.ListPatients);
            this.Controls.Add(this.ListNurses);
            this.Controls.Add(this.CreatePatient);
            this.Controls.Add(this.CreateNurse);
            this.Controls.Add(this.LPTAcuityLevel);
            this.Controls.Add(this.PatientAcuityLevel);
            this.Controls.Add(this.LPTCheifComplaint);
            this.Controls.Add(this.PatientChiefComplaint);
            this.Controls.Add(this.LPTLastname);
            this.Controls.Add(this.PatientLastname);
            this.Controls.Add(this.LPTFristname);
            this.Controls.Add(this.LPTPatientInfo);
            this.Controls.Add(this.PatientFirstname);
            this.Controls.Add(this.LRNAcuityLevel);
            this.Controls.Add(this.NurseAcutiyLevel);
            this.Controls.Add(this.LRNInitials);
            this.Controls.Add(this.NurseInitials);
            this.Controls.Add(this.LRNLastname);
            this.Controls.Add(this.NurseLastname);
            this.Controls.Add(this.LRNFristname);
            this.Controls.Add(this.LNurseInfo);
            this.Controls.Add(this.NurseFirstname);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AwareUnit";
            this.Text = "AwareUnit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox NurseFirstname;
        private System.Windows.Forms.Label LNurseInfo;
        private System.Windows.Forms.Label LRNFristname;
        private System.Windows.Forms.Label LRNLastname;
        private System.Windows.Forms.TextBox NurseLastname;
        private System.Windows.Forms.Label LRNInitials;
        private System.Windows.Forms.TextBox NurseInitials;
        private System.Windows.Forms.Label LRNAcuityLevel;
        private System.Windows.Forms.TextBox NurseAcutiyLevel;
        private System.Windows.Forms.Label LPTAcuityLevel;
        private System.Windows.Forms.TextBox PatientAcuityLevel;
        private System.Windows.Forms.Label LPTCheifComplaint;
        private System.Windows.Forms.TextBox PatientChiefComplaint;
        private System.Windows.Forms.Label LPTLastname;
        private System.Windows.Forms.TextBox PatientLastname;
        private System.Windows.Forms.Label LPTFristname;
        private System.Windows.Forms.Label LPTPatientInfo;
        private System.Windows.Forms.TextBox PatientFirstname;
        private System.Windows.Forms.Button CreateNurse;
        private System.Windows.Forms.Button CreatePatient;
        private System.Windows.Forms.ListBox ListNurses;
        private System.Windows.Forms.ListBox ListPatients;
        private System.Windows.Forms.ListBox UnassignedPatients;
        private System.Windows.Forms.ComboBox SelectUnit;
        private System.Windows.Forms.Label LUnit;
        private System.Windows.Forms.Button CreateUnit;
        private System.Windows.Forms.Label UnitAcronymDisplay;
        private System.Windows.Forms.LinkLabel RemoveNurse;
        private System.Windows.Forms.LinkLabel RemovePatient;
        private System.Windows.Forms.LinkLabel AddNurse;
        private System.Windows.Forms.ComboBox SelectNurseDropDown;
        private System.Windows.Forms.ComboBox SelectedPatientDropDown;
        private System.Windows.Forms.LinkLabel AddPatient;
        private System.Windows.Forms.RichTextBox AssiegnmentDisplay;
        private System.Windows.Forms.Label labelUnPt;
    }
}

